import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saved-links',
  templateUrl: './saved-links.component.html',
  styleUrls: ['./saved-links.component.css']
})
export class SavedLinksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
